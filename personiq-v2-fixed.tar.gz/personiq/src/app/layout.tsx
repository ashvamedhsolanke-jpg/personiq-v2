import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'PersonIQ — Discover any person. Beyond the basics.',description:'AI-powered public-person research with sourced facts, timelines and Wikimedia Commons imagery.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <>{children}</>}
